'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { redirect } from 'next/navigation';
import {
  BookOpen,
  PlayCircle,
  Clock,
  Award,
  TrendingUp,
  Users,
  MessageCircle,
  Star
} from 'lucide-react';

interface ReadingProgress {
  id: string;
  bookId: string;
  book: {
    title: string;
    authorName: string;
    coverImage?: string;
    pageCount?: number;
  };
  percentComplete: number;
  currentPage?: number;
  lastReadAt: string;
}

interface Assignment {
  id: string;
  title: string;
  description: string;
  book: {
    title: string;
    authorName: string;
  };
  dueDate: string;
  status: string;
}

interface Stats {
  booksRead: number;
  totalReadingTime: number;
  currentStreak: number;
  averageRating: number;
  classRanking: number;
  totalClasses: number;
}

export default function LearnerDashboard() {
  const { data: session, status } = useSession();
  const [readingProgress, setReadingProgress] = useState<ReadingProgress[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Redirect if not authenticated or not a learner
  useEffect(() => {
    if (status === 'loading') return;
    if (!session) {
      redirect('/login');
    }
    if (session.user?.role !== 'LEARNER') {
      redirect('/dashboard');
    }
  }, [session, status]);

  // Fetch dashboard data
  const fetchData = async () => {
    try {
      // These APIs would need to be implemented
      const [progressRes, assignmentsRes, statsRes] = await Promise.all([
        fetch('/api/learner/reading-progress'),
        fetch('/api/learner/assignments'),
        fetch('/api/learner/stats')
      ]);

      // For now, using mock data since APIs don't exist yet
      setReadingProgress([
        {
          id: '1',
          bookId: 'book1',
          book: { title: 'The Amazing Journey', authorName: 'Young Author', pageCount: 120 },
          percentComplete: 65,
          currentPage: 78,
          lastReadAt: new Date().toISOString()
        }
      ]);

      setAssignments([
        {
          id: '1',
          title: 'Read Chapter 5-7',
          description: 'Complete reading and answer discussion questions',
          book: { title: 'The Amazing Journey', authorName: 'Young Author' },
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'PENDING'
        }
      ]);

      setStats({
        booksRead: 12,
        totalReadingTime: 1440, // minutes
        currentStreak: 7,
        averageRating: 4.2,
        classRanking: 3,
        totalClasses: 2
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session?.user?.role === 'LEARNER') {
      fetchData();
    }
  }, [session]);

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Error: {error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Learning Dashboard</h1>
              <p className="mt-1 text-sm text-gray-500">
                Welcome back, {session?.user?.name}! Keep reading and learning.
              </p>
            </div>
            <button
              onClick={() => window.location.href = '/library'}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <BookOpen className="h-5 w-5" />
              Browse Library
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Books Read</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.booksRead}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Reading Time</p>
                  <p className="text-2xl font-bold text-gray-900">{Math.floor(stats.totalReadingTime / 60)}h</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Reading Streak</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.currentStreak} days</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <Award className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Class Rank</p>
                  <p className="text-lg font-bold text-gray-900">#{stats.classRanking}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Continue Reading */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Continue Reading</h2>
            </div>
            <div className="p-6">
              {readingProgress.length === 0 ? (
                <div className="text-center py-8">
                  <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No books in progress</p>
                  <p className="text-sm text-gray-400">Start reading a book assigned by your teacher</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {readingProgress.map((progress) => (
                    <div key={progress.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{progress.book.title}</h3>
                        <span className="text-sm text-gray-500">{progress.percentComplete}%</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">by {progress.book.authorName}</p>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex-1 bg-gray-200 rounded-full h-2 mr-4">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${progress.percentComplete}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-500">
                          Page {progress.currentPage} of {progress.book.pageCount}
                        </span>
                      </div>
                      <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg flex items-center justify-center gap-2">
                        <PlayCircle className="h-4 w-4" />
                        Continue Reading
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Assignments */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Upcoming Assignments</h2>
            </div>
            <div className="p-6">
              {assignments.length === 0 ? (
                <div className="text-center py-8">
                  <MessageCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No assignments</p>
                  <p className="text-sm text-gray-400">Your teacher will assign reading tasks here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {assignments.map((assignment) => (
                    <div key={assignment.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{assignment.title}</h3>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          assignment.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {assignment.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{assignment.book.title}</p>
                      <p className="text-sm text-gray-500 mb-3">{assignment.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">
                          Due: {new Date(assignment.dueDate).toLocaleDateString()}
                        </span>
                        <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                          View Details
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Quick Actions</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-3">
                <Users className="h-6 w-6 text-blue-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Join Book Club</p>
                  <p className="text-sm text-gray-500">Discuss books with classmates</p>
                </div>
              </button>

              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-3">
                <MessageCircle className="h-6 w-6 text-green-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Ask AI Helper</p>
                  <p className="text-sm text-gray-500">Get help with difficult words</p>
                </div>
              </button>

              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-3">
                <Star className="h-6 w-6 text-yellow-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Rate Books</p>
                  <p className="text-sm text-gray-500">Share your thoughts</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}