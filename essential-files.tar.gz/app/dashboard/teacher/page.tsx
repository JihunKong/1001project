'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { redirect } from 'next/navigation';
import {
  Users,
  BookOpen,
  Plus,
  Calendar,
  TrendingUp,
  CheckCircle,
  Clock,
  Award,
  Settings,
  MessageSquare
} from 'lucide-react';

interface Class {
  id: string;
  code: string;
  name: string;
  subject: string;
  gradeLevel: string;
  studentCount: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

interface StudentProgress {
  id: string;
  name: string;
  booksAssigned: number;
  booksCompleted: number;
  averageProgress: number;
  lastActivity: string;
  readingStreak: number;
}

interface Assignment {
  id: string;
  title: string;
  book: {
    title: string;
    authorName: string;
  };
  className: string;
  dueDate: string;
  completionRate: number;
  studentsCompleted: number;
  totalStudents: number;
}

interface Stats {
  totalStudents: number;
  activeClasses: number;
  booksAssigned: number;
  averageClassProgress: number;
  totalReadingHours: number;
  completedAssignments: number;
}

export default function TeacherDashboard() {
  const { data: session, status } = useSession();
  const [classes, setClasses] = useState<Class[]>([]);
  const [recentProgress, setRecentProgress] = useState<StudentProgress[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Redirect if not authenticated or not a teacher
  useEffect(() => {
    if (status === 'loading') return;
    if (!session) {
      redirect('/login');
    }
    if (session.user?.role !== 'TEACHER') {
      redirect('/dashboard');
    }
  }, [session, status]);

  // Fetch dashboard data
  const fetchData = async () => {
    try {
      // These APIs would need to be implemented
      // For now, using mock data since APIs don't exist yet
      setClasses([
        {
          id: '1',
          code: 'ENG5A1',
          name: 'English Literature 5A',
          subject: 'English',
          gradeLevel: '5th Grade',
          studentCount: 28,
          startDate: new Date().toISOString(),
          endDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString(),
          isActive: true
        },
        {
          id: '2',
          code: 'ENG5B2',
          name: 'English Literature 5B',
          subject: 'English',
          gradeLevel: '5th Grade',
          studentCount: 25,
          startDate: new Date().toISOString(),
          endDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString(),
          isActive: true
        }
      ]);

      setRecentProgress([
        {
          id: '1',
          name: 'Alice Johnson',
          booksAssigned: 5,
          booksCompleted: 3,
          averageProgress: 78,
          lastActivity: new Date().toISOString(),
          readingStreak: 12
        },
        {
          id: '2',
          name: 'Bob Smith',
          booksAssigned: 5,
          booksCompleted: 4,
          averageProgress: 92,
          lastActivity: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          readingStreak: 8
        }
      ]);

      setAssignments([
        {
          id: '1',
          title: 'Read Chapters 1-3',
          book: { title: 'The Amazing Journey', authorName: 'Young Author' },
          className: 'English Literature 5A',
          dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
          completionRate: 75,
          studentsCompleted: 21,
          totalStudents: 28
        }
      ]);

      setStats({
        totalStudents: 53,
        activeClasses: 2,
        booksAssigned: 15,
        averageClassProgress: 82,
        totalReadingHours: 2840,
        completedAssignments: 127
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session?.user?.role === 'TEACHER') {
      fetchData();
    }
  }, [session]);

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Error: {error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h1>
              <p className="mt-1 text-sm text-gray-500">
                Welcome back, {session?.user?.name}! Manage your classes and track student progress.
              </p>
            </div>
            <div className="flex gap-3">
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <Plus className="h-5 w-5" />
                New Class
              </button>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Assign Book
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Students</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalStudents}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Active Classes</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activeClasses}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Books Assigned</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.booksAssigned}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Avg Progress</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.averageClassProgress}%</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* My Classes */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">My Classes</h2>
            </div>
            <div className="p-6">
              {classes.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No classes created</p>
                  <button className="mt-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 mx-auto">
                    <Plus className="h-4 w-4" />
                    Create First Class
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {classes.map((classItem) => (
                    <div key={classItem.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{classItem.name}</h3>
                        <span className="bg-green-100 text-green-800 px-2 py-1 text-xs rounded-full">
                          {classItem.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>Code: <span className="font-mono font-medium">{classItem.code}</span></p>
                        <p>Subject: {classItem.subject} | Grade: {classItem.gradeLevel}</p>
                        <p>Students: {classItem.studentCount}</p>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                          View Students
                        </button>
                        <button className="text-purple-600 hover:text-purple-800 text-sm font-medium">
                          Assign Books
                        </button>
                        <button className="text-gray-600 hover:text-gray-800 text-sm font-medium">
                          <Settings className="h-4 w-4 inline" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Student Progress */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Student Progress</h2>
            </div>
            <div className="p-6">
              {recentProgress.length === 0 ? (
                <div className="text-center py-8">
                  <TrendingUp className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No student activity</p>
                  <p className="text-sm text-gray-400">Student progress will appear here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {recentProgress.map((student) => (
                    <div key={student.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{student.name}</h3>
                        <span className="text-sm text-gray-500">
                          {student.readingStreak} day streak
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Books Completed</p>
                          <p className="font-medium">{student.booksCompleted}/{student.booksAssigned}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Average Progress</p>
                          <p className="font-medium">{student.averageProgress}%</p>
                        </div>
                      </div>
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-500">Overall Progress</span>
                          <span className="text-gray-700">{student.averageProgress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${student.averageProgress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Recent Assignments */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Recent Assignments</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Assignment
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Book
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Class
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Due Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Completion
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {assignments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex flex-col items-center">
                        <Calendar className="h-12 w-12 text-gray-300 mb-4" />
                        <p>No assignments created</p>
                        <p className="text-sm">Start by assigning books to your classes</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  assignments.map((assignment) => (
                    <tr key={assignment.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {assignment.title}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{assignment.book.title}</div>
                        <div className="text-sm text-gray-500">by {assignment.book.authorName}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {assignment.className}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(assignment.dueDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-1 min-w-0 mr-4">
                            <div className="flex items-center justify-between text-sm mb-1">
                              <span>{assignment.studentsCompleted}/{assignment.totalStudents}</span>
                              <span>{assignment.completionRate}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-green-600 h-2 rounded-full"
                                style={{ width: `${assignment.completionRate}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button className="text-blue-600 hover:text-blue-900">
                            View
                          </button>
                          <button className="text-green-600 hover:text-green-900">
                            <MessageSquare className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}