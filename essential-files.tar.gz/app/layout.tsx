import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import Providers from './providers';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: '1001 Stories - Global Education Platform',
  description: 'Discover, publish, and share stories from children in underserved communities worldwide.',
  keywords: ['education', 'stories', 'children', 'global', 'non-profit'],
  authors: [{ name: '1001 Stories Team' }],
  viewport: 'width=device-width, initial-scale=1',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}