export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Welcome to 1001 Stories
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Discover, publish, and share stories from children in underserved communities around the world.
          </p>
          <div className="space-x-4">
            <a
              href="/dashboard/learner"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Learning
            </a>
            <a
              href="/dashboard/teacher"
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
            >
              Teach Stories
            </a>
            <a
              href="/dashboard/volunteer"
              className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors"
            >
              Volunteer
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}