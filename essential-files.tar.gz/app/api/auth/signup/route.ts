import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { UserRole } from '@prisma/client';
import { z } from 'zod';

// Validation schema for user registration
const SignupSchema = z.object({
  email: z.string()
    .email('Please enter a valid email address')
    .min(5, 'Email must be at least 5 characters')
    .max(255, 'Email must be less than 255 characters')
    .toLowerCase(),
  name: z.string()
    .min(1, 'Name is required')
    .max(100, 'Name must be less than 100 characters')
    .trim(),
  role: z.enum(['LEARNER', 'TEACHER', 'VOLUNTEER', 'INSTITUTION'])
    .refine(val => ['LEARNER', 'TEACHER', 'VOLUNTEER', 'INSTITUTION'].includes(val), {
      message: 'Please select a valid role'
    }),
  // Optional profile information
  organization: z.string()
    .max(200, 'Organization must be less than 200 characters')
    .trim()
    .optional(),
  bio: z.string()
    .max(1000, 'Bio must be less than 1000 characters')
    .trim()
    .optional(),
  phone: z.string()
    .max(20, 'Phone must be less than 20 characters')
    .trim()
    .optional(),
  // Terms acceptance
  acceptedTerms: z.boolean()
    .refine(val => val === true, 'You must accept the terms and conditions'),
  acceptedPrivacy: z.boolean()
    .refine(val => val === true, 'You must accept the privacy policy'),
});

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();

    let validatedData;
    try {
      validatedData = SignupSchema.parse(body);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return NextResponse.json(
          {
            error: 'Validation failed',
            details: error.issues.map(err => ({
              field: err.path.join('.'),
              message: err.message
            }))
          },
          { status: 400 }
        );
      }
      return NextResponse.json(
        { error: 'Invalid request data' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: validatedData.email }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'A user with this email already exists' },
        { status: 409 }
      );
    }

    // Create user with transaction to ensure data consistency
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email: validatedData.email,
          name: validatedData.name,
          role: validatedData.role as UserRole,
          emailVerified: null, // Will be verified via magic link
        },
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          createdAt: true,
        }
      });

      // Create user profile
      await tx.profile.create({
        data: {
          userId: user.id,
          firstName: validatedData.name.split(' ')[0] || validatedData.name,
          lastName: validatedData.name.split(' ').slice(1).join(' ') || null,
          organization: validatedData.organization,
          bio: validatedData.bio,
          phone: validatedData.phone,
          language: 'en',
          timezone: 'UTC',
        }
      });

      // Create default subscription
      await tx.subscription.create({
        data: {
          userId: user.id,
          plan: 'FREE',
          status: 'ACTIVE',
        }
      });

      // Create volunteer profile if role is VOLUNTEER
      if (validatedData.role === 'VOLUNTEER') {
        await tx.volunteerProfile.create({
          data: {
            userId: user.id,
            verificationStatus: 'PENDING',
            languageLevels: {},
            availableSlots: {},
          }
        });
      }

      return user;
    });

    return NextResponse.json({
      message: 'User registration successful',
      user: result,
      nextStep: 'email_verification'
    }, { status: 201 });

  } catch (error) {
    console.error('Error during user registration:', error);

    // Handle specific database errors
    if (error instanceof Error) {
      if (error.message.includes('Unique constraint')) {
        return NextResponse.json(
          { error: 'A user with this email already exists' },
          { status: 409 }
        );
      }
    }

    return NextResponse.json(
      { error: 'Internal server error during registration' },
      { status: 500 }
    );
  }
}

// Method not allowed for other HTTP methods
export async function GET() {
  return NextResponse.json(
    { error: 'Method not allowed' },
    { status: 405 }
  );
}