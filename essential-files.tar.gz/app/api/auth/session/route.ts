import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    // Get session from NextAuth
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({
        authenticated: false,
        user: null,
        expires: null
      });
    }

    // Get additional user details from database
    const userDetails = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        emailVerified: true,
        createdAt: true,
        profile: {
          select: {
            firstName: true,
            lastName: true,
            organization: true,
            timezone: true,
            language: true,
          }
        },
        subscription: {
          select: {
            plan: true,
            status: true,
            maxStudents: true,
            canAccessPremium: true,
            canDownloadPDF: true,
            canCreateClasses: true,
          }
        }
      }
    });

    if (!userDetails) {
      return NextResponse.json({
        authenticated: false,
        user: null,
        expires: null,
        error: 'User not found in database'
      }, { status: 404 });
    }

    // Get role-specific information
    let roleSpecificData = {};

    switch (userDetails.role) {
      case 'TEACHER':
        // Get teacher's classes count
        const classCount = await prisma.class.count({
          where: { teacherId: userDetails.id }
        });
        roleSpecificData = {
          classCount,
          canCreateClasses: userDetails.subscription?.canCreateClasses || false
        };
        break;

      case 'LEARNER':
        // Get student's enrollments
        const enrollmentCount = await prisma.classEnrollment.count({
          where: { studentId: userDetails.id }
        });
        roleSpecificData = {
          enrollmentCount
        };
        break;

      case 'VOLUNTEER':
        // Get volunteer submission stats
        const submissionCount = await prisma.volunteerSubmission.count({
          where: { volunteerId: userDetails.id }
        });
        const volunteerProfile = await prisma.volunteerProfile.findUnique({
          where: { userId: userDetails.id },
          select: {
            verificationStatus: true,
            totalHours: true,
            rating: true,
          }
        });
        roleSpecificData = {
          submissionCount,
          verificationStatus: volunteerProfile?.verificationStatus || 'PENDING',
          totalHours: volunteerProfile?.totalHours || 0,
          rating: volunteerProfile?.rating || 5.0,
        };
        break;

      case 'ADMIN':
        // Get admin dashboard stats
        const totalUsers = await prisma.user.count();
        const totalBooks = await prisma.book.count();
        const totalClasses = await prisma.class.count();
        roleSpecificData = {
          totalUsers,
          totalBooks,
          totalClasses,
          hasFullAccess: true
        };
        break;
    }

    return NextResponse.json({
      authenticated: true,
      user: {
        id: userDetails.id,
        email: userDetails.email,
        name: userDetails.name,
        role: userDetails.role,
        emailVerified: userDetails.emailVerified,
        createdAt: userDetails.createdAt,
        profile: userDetails.profile,
        subscription: userDetails.subscription,
        roleSpecific: roleSpecificData
      },
      expires: session.expires
    });

  } catch (error) {
    console.error('Error fetching session information:', error);

    return NextResponse.json(
      {
        authenticated: false,
        user: null,
        expires: null,
        error: 'Internal server error'
      },
      { status: 500 }
    );
  }
}

// POST method for session refresh/validation
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json({
        valid: false,
        message: 'No active session found'
      }, { status: 401 });
    }

    // Validate that user still exists and is active
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: {
        id: true,
        email: true,
        emailVerified: true,
        role: true,
        deletedAt: true, // Check if user was soft deleted
      }
    });

    if (!user || user.deletedAt) {
      return NextResponse.json({
        valid: false,
        message: 'User account no longer exists'
      }, { status: 401 });
    }

    return NextResponse.json({
      valid: true,
      message: 'Session is valid',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        emailVerified: user.emailVerified,
      }
    });

  } catch (error) {
    console.error('Error validating session:', error);

    return NextResponse.json({
      valid: false,
      message: 'Internal server error'
    }, { status: 500 });
  }
}

// Method not allowed for other HTTP methods
export async function PUT() {
  return NextResponse.json(
    { error: 'Method not allowed' },
    { status: 405 }
  );
}

export async function DELETE() {
  return NextResponse.json(
    { error: 'Method not allowed' },
    { status: 405 }
  );
}