'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import RichTextEditor from './RichTextEditor';
import {
  Save,
  Send,
  X,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

interface StorySubmissionFormProps {
  onClose?: () => void;
  onSuccess?: () => void;
  initialData?: {
    title?: string;
    authorAlias?: string;
    textContent?: string;
    summary?: string;
    ageRange?: string;
    category?: string[];
    tags?: string[];
    targetAudience?: string;
    licenseType?: string;
  };
}

export default function StorySubmissionForm({
  onClose,
  onSuccess,
  initialData
}: StorySubmissionFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    authorAlias: initialData?.authorAlias || '',
    textContent: initialData?.textContent || '',
    summary: initialData?.summary || '',
    ageRange: initialData?.ageRange || '',
    category: initialData?.category || [],
    tags: initialData?.tags || [],
    targetAudience: initialData?.targetAudience || '',
    licenseType: initialData?.licenseType || 'CC-BY',
  });

  const ageRanges = [
    { value: '3-5', label: 'Early Childhood (3-5 years)' },
    { value: '6-8', label: 'Early Elementary (6-8 years)' },
    { value: '9-11', label: 'Late Elementary (9-11 years)' },
    { value: '12-14', label: 'Middle School (12-14 years)' },
    { value: '15-18', label: 'High School (15-18 years)' },
    { value: 'All Ages', label: 'All Ages' },
  ];

  const categories = [
    'Adventure', 'Fantasy', 'Mystery', 'Science Fiction', 'Historical Fiction',
    'Contemporary Fiction', 'Biography', 'Non-fiction', 'Poetry', 'Folktale',
    'Fable', 'Myth', 'Educational', 'Social Issues', 'Cultural'
  ];

  const licenseTypes = [
    { value: 'CC-BY', label: 'Creative Commons - Attribution (CC BY)' },
    { value: 'CC-BY-SA', label: 'Creative Commons - Attribution-ShareAlike (CC BY-SA)' },
    { value: 'CC-BY-NC', label: 'Creative Commons - Attribution-NonCommercial (CC BY-NC)' },
    { value: 'Public Domain', label: 'Public Domain' },
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    setError(null);
  };

  const handleTagsChange = (value: string) => {
    const tags = value.split(',').map(tag => tag.trim()).filter(Boolean);
    handleInputChange('tags', tags);
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    const updatedCategories = checked
      ? [...formData.category, category]
      : formData.category.filter(c => c !== category);
    handleInputChange('category', updatedCategories);
  };

  const validateForm = () => {
    if (!formData.title.trim()) return 'Title is required';
    if (!formData.authorAlias.trim()) return 'Author alias is required';
    if (!formData.textContent.trim()) return 'Story content is required';
    if (!formData.summary.trim()) return 'Summary is required';
    if (formData.textContent.length < 100) return 'Story content must be at least 100 characters';
    if (formData.summary.length < 50) return 'Summary must be at least 50 characters';
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/volunteer/submissions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit story');
      }

      const result = await response.json();
      setSuccess(true);

      // Show success message and redirect after delay
      setTimeout(() => {
        if (onSuccess) {
          onSuccess();
        } else {
          router.push('/dashboard/volunteer');
        }
      }, 2000);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
          <div className="text-center">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Story Submitted Successfully!
            </h3>
            <p className="text-gray-600 mb-6">
              Your story has been submitted for review. You'll be notified when it's approved.
            </p>
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
      <div className="bg-white rounded-lg w-full max-w-4xl mx-4 my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Submit New Story
          </h2>
          {onClose && (
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-6 w-6" />
            </button>
          )}
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {/* Title and Author */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Story Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="input"
                placeholder="Enter your story title"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Author Alias *
              </label>
              <input
                type="text"
                value={formData.authorAlias}
                onChange={(e) => handleInputChange('authorAlias', e.target.value)}
                className="input"
                placeholder="How should you be credited?"
                required
              />
            </div>
          </div>

          {/* Story Content */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Story Content *
            </label>
            <RichTextEditor
              content={formData.textContent}
              onChange={(content) => handleInputChange('textContent', content)}
              placeholder="Write your story here... Use the toolbar above to format your text."
            />
          </div>

          {/* Summary */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Story Summary *
            </label>
            <textarea
              value={formData.summary}
              onChange={(e) => handleInputChange('summary', e.target.value)}
              className="textarea h-24"
              placeholder="Provide a brief summary of your story (50+ characters)"
              required
            />
          </div>

          {/* Age Range and Target Audience */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age Range
              </label>
              <select
                value={formData.ageRange}
                onChange={(e) => handleInputChange('ageRange', e.target.value)}
                className="input"
              >
                <option value="">Select age range</option>
                {ageRanges.map((range) => (
                  <option key={range.value} value={range.value}>
                    {range.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Audience
              </label>
              <input
                type="text"
                value={formData.targetAudience}
                onChange={(e) => handleInputChange('targetAudience', e.target.value)}
                className="input"
                placeholder="e.g., ESL students, rural communities"
              />
            </div>
          </div>

          {/* Categories */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Categories
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
              {categories.map((category) => (
                <label key={category} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.category.includes(category)}
                    onChange={(e) => handleCategoryChange(category, e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">{category}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tags
            </label>
            <input
              type="text"
              value={formData.tags.join(', ')}
              onChange={(e) => handleTagsChange(e.target.value)}
              className="input"
              placeholder="Enter tags separated by commas (e.g., friendship, adventure, courage)"
            />
          </div>

          {/* License */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              License Type
            </label>
            <select
              value={formData.licenseType}
              onChange={(e) => handleInputChange('licenseType', e.target.value)}
              className="input"
            >
              {licenseTypes.map((license) => (
                <option key={license.value} value={license.value}>
                  {license.label}
                </option>
              ))}
            </select>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary"
                disabled={loading}
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Submit Story
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}